buildscript {
    repositories {
        google()  // Ensure Google's Maven repository is included
        mavenCentral()  // Include Maven Central repository
        jcenter() // if required
    }
    dependencies {
        classpath("com.android.tools.build:gradle:8.2.2")  // Ensure the correct version of Android Gradle Plugin
        classpath("com.google.gms:google-services:4.4.2")  // Firebase plugin
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
        jcenter() // if required
    }
}

plugins {
    // Add the dependency for the Google services Gradle plugin
    id("com.google.gms.google-services") version "4.4.2" apply false
}
