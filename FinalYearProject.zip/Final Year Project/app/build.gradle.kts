plugins {
    id("com.android.application")
    id("com.google.gms.google-services") // Add Firebase services plugin if using Firebase
}

android {
    namespace = "com.example.finalyearproject"
    compileSdk = 35  // Update to SDK 35

    defaultConfig {
        applicationId = "com.example.finalyearproject"
        minSdk = 24
        targetSdk = 35  // Update to SDK 35
        versionCode = 1
        versionName = "1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                    getDefaultProguardFile("proguard-android-optimize.txt"),
                    "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    sourceSets {
        getByName("main") {
            java {
                srcDirs("src/main/java")
            }
        }
    }
}

dependencies {
    // Firebase BoM for automatic version management
    //implementation platform("com.google.firebase:firebase-bom:31.0.0")

    // Firebase Authentication SDK (managed by BoM)
    implementation("com.google.android.gms:play-services-auth:20.0.0")

    // Firebase UI for authentication
    implementation("com.firebaseui:firebase-ui-auth:8.0.1")  // Add Firebase UI Auth dependency
    implementation("com.google.firebase:firebase-auth:21.2.0") // Firebase Authentication dependency

    // Google Maps SDK
    implementation("com.google.android.gms:play-services-maps:19.1.0")

    // Google Places API
    implementation("com.google.android.libraries.places:places:4.1.0")

    // AndroidX libraries
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.1")

    // Testing dependencies
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")

    // Location services SDK (updated version for compatibility)
    implementation("com.google.android.gms:play-services-location:21.3.0")

    // Room dependencies
    implementation("androidx.room:room-runtime:2.6.1")  // Latest Room runtime
    annotationProcessor("androidx.room:room-compiler:2.6.1")  // Room compiler for Java
    implementation("androidx.room:room-ktx:2.6.1")  // If using Kotlin

    // RecyclerView
    implementation("androidx.recyclerview:recyclerview:1.4.0")

    // Firebase authentication SDK for Google services
    implementation("com.google.android.gms:play-services-auth:21.3.0")
}

// Apply the Google services plugin to the app module
apply(plugin = "com.google.gms.google-services")
