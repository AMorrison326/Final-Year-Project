package com.example.finalyearproject.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "packing_list")
public class PackingList {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String ageGroup;
    private String item;
    private String type;

    // Constructor with all three parameters
    public PackingList(String ageGroup, String item, String type) {
        this.ageGroup = ageGroup;
        this.item = item;
        this.type = type;
    }

    // Optional Constructor for Custom Items (defaulting type to "Custom")
    public PackingList(String ageGroup, String item) {
        this.ageGroup = ageGroup;
        this.item = item;
        this.type = "Custom"; // Default type for user-added items
    }

    // Default constructor (needed by Room)
    public PackingList() {}

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
