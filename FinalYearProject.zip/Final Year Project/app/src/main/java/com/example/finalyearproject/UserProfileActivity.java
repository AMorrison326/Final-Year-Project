package com.example.finalyearproject;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class UserProfileActivity extends AppCompatActivity {

    private EditText userName, userEmail, userPhone, preferredRoute, vehicleType, travelPreferences, fuelType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);  // Ensure this is the correct layout file

        // Initialize the EditTexts
        userName = findViewById(R.id.user_name);
        userEmail = findViewById(R.id.user_email);
        userPhone = findViewById(R.id.user_phone);
        preferredRoute = findViewById(R.id.preferred_route);
        vehicleType = findViewById(R.id.vehicle_type);
        travelPreferences = findViewById(R.id.travel_preferences);
        fuelType = findViewById(R.id.fuel_type);  // New EditText for fuel type

        // Load saved data if available
        loadProfile();

        // Set click listener for the save button
        findViewById(R.id.save_profile_button).setOnClickListener(v -> saveProfile());
    }

    private void saveProfile() {
        // Get the input values
        String name = userName.getText().toString();
        String email = userEmail.getText().toString();
        String phone = userPhone.getText().toString();
        String route = preferredRoute.getText().toString();
        String vehicle = vehicleType.getText().toString();
        String preferences = travelPreferences.getText().toString();
        String fuel = fuelType.getText().toString();  // Get the fuel type input

        // Save this data to SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_profile", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("user_name", name);
        editor.putString("user_email", email);
        editor.putString("user_phone", phone);
        editor.putString("preferred_route", route);
        editor.putString("vehicle_type", vehicle);
        editor.putString("travel_preferences", preferences);
        editor.putString("fuel_type", fuel);  // Save the fuel type
        editor.apply();

        Toast.makeText(this, "Profile Saved", Toast.LENGTH_SHORT).show();
    }

    private void loadProfile() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_profile", MODE_PRIVATE);
        userName.setText(sharedPreferences.getString("user_name", ""));
        userEmail.setText(sharedPreferences.getString("user_email", ""));
        userPhone.setText(sharedPreferences.getString("user_phone", ""));
        preferredRoute.setText(sharedPreferences.getString("preferred_route", ""));
        vehicleType.setText(sharedPreferences.getString("vehicle_type", ""));
        travelPreferences.setText(sharedPreferences.getString("travel_preferences", ""));
        fuelType.setText(sharedPreferences.getString("fuel_type", ""));  // Load the fuel type
    }
}
