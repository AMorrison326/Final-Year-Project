package com.example.finalyearproject.database;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
import java.util.Arrays;
import java.util.concurrent.Executors;
import java.util.List;

@Database(entities = {PackingList.class}, version = 2, exportSchema = false)
public abstract class PackingListDatabase extends RoomDatabase {

    private static volatile PackingListDatabase instance;

    public abstract PackingListDao packingListDao();

    public static synchronized PackingListDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            PackingListDatabase.class, "packing_list_database")
                    .fallbackToDestructiveMigration() // Clears DB on version change
                    .addCallback(prepopulateDatabaseCallback)
                    .build();
        }
        return instance;
    }

    private static final RoomDatabase.Callback prepopulateDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            Executors.newSingleThreadExecutor().execute(() -> {
                PackingListDao dao = instance.packingListDao();
                List<PackingList> packingList = Arrays.asList(getPredefinedPackingLists());
                dao.insertAll(packingList); // ✅ Now correctly passing a List
            });
        }
    };

    public static PackingList[] getPredefinedPackingLists() {
        return new PackingList[]{
                new PackingList("Children", "Defined1", "Essentials"),
                new PackingList("Children", "Defined2", "Essentials"),
                new PackingList("Children", "Defined3", "Food"),
                new PackingList("Children", "Defined4", "Entertainment"),

                new PackingList("Teenagers", "Headphones", "Electronics"),
                new PackingList("Teenagers", "Power Bank", "Electronics"),
                new PackingList("Teenagers", "Clothes", "Essentials"),
                new PackingList("Teenagers", "Sunglasses", "Accessories"),

                new PackingList("Adults", "Passport", "Documents"),
                new PackingList("Adults", "Wallet", "Essentials"),
                new PackingList("Adults", "Phone Charger", "Electronics"),
                new PackingList("Adults", "First Aid Kit", "Health"),

                new PackingList("Elderly", "Medications", "Health"),
                new PackingList("Elderly", "Reading Glasses", "Essentials"),
                new PackingList("Elderly", "Comfortable Shoes", "Clothing"),
                new PackingList("Elderly", "Snacks", "Food")
        };
    }
}
