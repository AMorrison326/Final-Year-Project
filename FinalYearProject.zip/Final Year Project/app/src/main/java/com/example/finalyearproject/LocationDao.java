package com.example.finalyearproject;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Delete;
import java.util.List;

@Dao
public interface LocationDao {

    @Query("SELECT * FROM locations")
    LiveData<List<Location>> getAllLocations();  // ✅ Correct return type

    @Insert
    void insert(Location location);

    @Delete
    void delete(Location location);
}
