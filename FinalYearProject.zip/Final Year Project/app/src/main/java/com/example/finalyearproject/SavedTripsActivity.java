package com.example.finalyearproject;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class SavedTripsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TripAdapter tripAdapter;
    private TripViewModel tripViewModel; // Corrected to use TripViewModel

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_trips);

        recyclerViewSetup();
        setupViewModel();
    }

    private void recyclerViewSetup() {
        recyclerView = findViewById(R.id.recycler_view); // Make sure this ID matches your RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // Use linear layout manager for vertical list
        tripAdapter = new TripAdapter(this); // Create the TripAdapter
        recyclerView.setAdapter(tripAdapter); // Set the adapter for the RecyclerView
    }

    private void setupViewModel() {
        // Use TripViewModel to observe the trips
        tripViewModel = new ViewModelProvider(this).get(TripViewModel.class); // Initialize the ViewModel

        // Observe the LiveData from ViewModel
        tripViewModel.getAllTrips().observe(this, trips -> {
            if (trips != null) {
                tripAdapter.setTrips(trips); // Update adapter with the list of trips
            }
        });
    }
}
