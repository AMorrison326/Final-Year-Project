package com.example.finalyearproject.database;

import android.app.Application;
import androidx.lifecycle.LiveData;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PackingListRepository {
    private final PackingListDao packingListDao;
    private final ExecutorService executorService;

    public PackingListRepository(Application application) {
        PackingListDatabase database = PackingListDatabase.getInstance(application);
        packingListDao = database.packingListDao();
        executorService = Executors.newFixedThreadPool(2);
    }
 
    public LiveData<List<String>> getAgeGroups() {
        return packingListDao.getAgeGroups();
    }

    public LiveData<List<PackingList>> getPackingListByAgeGroup(String ageGroup) {
        return packingListDao.getPackingListByAgeGroup(ageGroup);
    }

    public void insertItem(PackingList item) {
        executorService.execute(() -> packingListDao.insert(item)); // ✅ Corrected
    }
}
