package com.example.finalyearproject;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import java.util.List;

public class TripRepository {

    private final MutableLiveData<List<Trip>> allTrips;

    // Constructor to initialize the repository
    public TripRepository() {
        allTrips = new MutableLiveData<>();
        loadTrips(); // Load trips when the repository is created
    }

    // This method simulates loading trips (you can replace it with actual data fetching logic)
    private void loadTrips() {
        List<Trip> trips = new ArrayList<>();

        // Add sample trips
        trips.add(new Trip("Trip to Paris", "Paris", "2023-05-01", "2023-05-07"));
        trips.add(new Trip("Trip to London", "London", "2023-06-01", "2023-06-07"));
        trips.add(new Trip("Trip to New York", "New York", "2023-07-01", "2023-07-07"));

        allTrips.setValue(trips); // Set the value of the trips in LiveData
    }

    // Method to fetch all trips (returns LiveData)
    public LiveData<List<Trip>> getAllTrips() {
        return allTrips;
    }
}
