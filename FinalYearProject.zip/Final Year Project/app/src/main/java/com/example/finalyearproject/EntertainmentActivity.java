package com.example.finalyearproject;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;

public class EntertainmentActivity extends AppCompatActivity {

    private ListView podcastListView;
    private String[] podcastList = {"Podcast 1", "Podcast 2", "Podcast 3", "Podcast 4"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entertainment);

        // Reference the ListView with ID 'podcast_list'
        //podcastListView = findViewById(R.id.podcast_list);

        // Set up the adapter for the ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, podcastList);
        podcastListView.setAdapter(adapter);
    }
}
