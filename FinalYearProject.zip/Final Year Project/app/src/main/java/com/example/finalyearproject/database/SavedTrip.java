package com.example.finalyearproject.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "saved_trips")
public class SavedTrip {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String destination;
    public String startDate;
    public String endDate;
}
