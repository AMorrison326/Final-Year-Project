package com.example.finalyearproject;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class TripViewModel extends ViewModel {

    private final TripRepository tripRepository;

    public TripViewModel() {
        tripRepository = new TripRepository(); // Initialize the repository
    }

    // Fetch all trips from the repository
    public LiveData<List<Trip>> getAllTrips() {
        return tripRepository.getAllTrips(); // Return the LiveData from the repository
    }
}
