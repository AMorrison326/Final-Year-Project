package com.example.finalyearproject;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Arrays;

public class JourneyActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private JourneyAdapter journeyAdapter;
    private List<String> locationsList;  // Replace with your actual data type

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_journey);

        recyclerView = findViewById(R.id.recycler_view_journey_locations);
        locationsList = getLocationsData();  // Replace with your method to fetch data

        journeyAdapter = new JourneyAdapter(locationsList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(journeyAdapter);
    }

    private List<String> getLocationsData() {
        // Replace with your actual logic for fetching data
        return Arrays.asList("Location 1", "Location 2", "Location 3");
    }
}
