package com.example.finalyearproject;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import java.util.List;

public class LocationViewModel extends AndroidViewModel {
    private final LocationRepository repository;
    private final LiveData<List<Location>> allLocations;

    public LocationViewModel(@NonNull Application application) {
        super(application);
        repository = new LocationRepository(application);
        allLocations = repository.getAllLocations(); // ✅ Now correctly using LiveData
    }

    public LiveData<List<Location>> getAllLocations() {
        return allLocations;
    }
}
