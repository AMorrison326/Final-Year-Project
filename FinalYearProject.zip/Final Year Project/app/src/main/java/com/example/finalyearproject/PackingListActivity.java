package com.example.finalyearproject;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalyearproject.database.PackingList;
import com.example.finalyearproject.database.PackingListRepository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PackingListActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private PackingListAdapter adapter;
    private Spinner spinnerAge;
    private PackingListRepository repository;
    private EditText editTextNewItem;
    private Button buttonAddItem;
    private String selectedAgeGroup;

    private final Map<String, List<String>> predefinedPackingLists = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_packing_list);

        // Initialize UI elements
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        editTextNewItem = findViewById(R.id.edit_text_new_item);
        buttonAddItem = findViewById(R.id.button_add_item);
        spinnerAge = findViewById(R.id.spinner_age);
        repository = new PackingListRepository(getApplication());

        // Initialize adapter with an empty list
        adapter = new PackingListAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        // Define Predefined Packing Lists
        initializePredefinedPackingLists();

        // Load and populate spinner
        loadAgeGroups();

        // Spinner selection listener
        setupSpinnerListener();

        // Button listener for adding custom items
        buttonAddItem.setOnClickListener(view -> {
            String newItem = editTextNewItem.getText().toString().trim();
            if (!newItem.isEmpty() && selectedAgeGroup != null) {
                addCustomItem(newItem);
            } else {
                Toast.makeText(this, "Please enter an item and select an age group", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initializePredefinedPackingLists() {
        predefinedPackingLists.put("Children", List.of("Toys", "Snacks", "Extra Clothes", "Water Bottle"));
        predefinedPackingLists.put("Teens", List.of("Phone Charger", "Headphones", "Notebook", "Snacks"));
        predefinedPackingLists.put("Adults", List.of("Passport", "Wallet", "Sunglasses", "Travel Pillow"));
        predefinedPackingLists.put("Elderly", List.of("Medication", "Reading Glasses", "Comfortable Shoes", "Water Bottle"));
    }


    private void loadAgeGroups() {
        repository.getAgeGroups().observe(this, new Observer<List<String>>() {
            @Override
            public void onChanged(List<String> ageGroups) {
                ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(PackingListActivity.this,
                        android.R.layout.simple_spinner_item, ageGroups);
                spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerAge.setAdapter(spinnerAdapter);
            }
        });
    }

    private void setupSpinnerListener() {
        spinnerAge.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedAgeGroup = (String) parent.getItemAtPosition(position);
                loadPackingList(selectedAgeGroup);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedAgeGroup = null;
            }
        });
    }

    private void loadPackingList(String ageGroup) {
        List<PackingList> items = new ArrayList<>();

        // Load predefined items if available
        if (predefinedPackingLists.containsKey(ageGroup)) {
            for (String item : predefinedPackingLists.get(ageGroup)) {
                items.add(new PackingList(ageGroup, item, "General")); // Adding "General" as default type
            }
        }

        // Load custom items from the database
        repository.getPackingListByAgeGroup(ageGroup).observe(this, customItems -> {
            items.addAll(customItems);
            adapter.updatePackingList(items);
        });
    }

    private void addCustomItem(String item) {
        PackingList newItem = new PackingList(selectedAgeGroup, item);
        repository.insertItem(newItem);

        // Refresh the list after adding the item
        loadPackingList(selectedAgeGroup);
        editTextNewItem.setText("");
        Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();
    }
}
