package com.example.finalyearproject;

import java.util.ArrayList;

public class TripManager {
    private ArrayList<Trip> trips;

    public TripManager() {
        trips = new ArrayList<>();
    }

    // Add a new trip
    public void addTrip(Trip trip) {
        trips.add(trip);
    }

    // Get all trips
    public ArrayList<Trip> getTrips() {
        return trips;
    }

    // Edit a trip by index
    public void editTrip(int index, Trip updatedTrip) {
        if (index >= 0 && index < trips.size()) {
            trips.set(index, updatedTrip);
        }
    }

    // Get a specific trip by index
    public Trip getTrip(int index) {
        if (index >= 0 && index < trips.size()) {
            return trips.get(index);
        }
        return null;
    }
}
