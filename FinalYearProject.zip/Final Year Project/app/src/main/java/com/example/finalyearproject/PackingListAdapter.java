package com.example.finalyearproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.finalyearproject.database.PackingList;
import java.util.List;

public class PackingListAdapter extends RecyclerView.Adapter<PackingListAdapter.ViewHolder> {
    private List<PackingList> packingList;

    public PackingListAdapter(List<PackingList> packingList) {
        this.packingList = packingList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_packing_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PackingList item = packingList.get(position);
        holder.textItem.setText(item.getItem());
    }

    @Override
    public int getItemCount() {
        return packingList.size();
    }

    public void updatePackingList(List<PackingList> newList) {
        packingList = newList;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textItem;

        ViewHolder(View itemView) {
            super(itemView);
            textItem = itemView.findViewById(R.id.text_item);
        }
    }
}
