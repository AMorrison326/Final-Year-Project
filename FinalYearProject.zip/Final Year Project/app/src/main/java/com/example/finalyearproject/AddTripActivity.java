package com.example.finalyearproject;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.finalyearproject.Trip;
import com.example.finalyearproject.TripManager;

public class AddTripActivity extends AppCompatActivity {

    private EditText edtTripName, edtTripDestination, edtStartDate, edtEndDate;
    private Button btnSaveTrip;
    private TripManager tripManager;
    private int editIndex = -1; // -1 indicates no editing

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_trip);

        edtTripName = findViewById(R.id.edt_trip_name);
        edtTripDestination = findViewById(R.id.edt_trip_destination);
        edtStartDate = findViewById(R.id.edt_trip_start_date);
        edtEndDate = findViewById(R.id.edt_trip_end_date);
        btnSaveTrip = findViewById(R.id.btn_save_trip);

        tripManager = new TripManager();

        // Check if we are editing an existing trip
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            editIndex = extras.getInt("editIndex", -1);
            if (editIndex != -1) {
                Trip trip = tripManager.getTrips().get(editIndex);
                edtTripName.setText(trip.getName());
                edtTripDestination.setText(trip.getDestination());
                edtStartDate.setText(trip.getStartDate());
                edtEndDate.setText(trip.getEndDate());
                btnSaveTrip.setText("Update Trip");
            }
        }

        btnSaveTrip.setOnClickListener(v -> {
            String name = edtTripName.getText().toString();
            String destination = edtTripDestination.getText().toString();
            String startDate = edtStartDate.getText().toString();
            String endDate = edtEndDate.getText().toString();

            if (name.isEmpty() || destination.isEmpty() || startDate.isEmpty() || endDate.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            Trip newTrip = new Trip(name, destination, startDate, endDate);

            if (editIndex == -1) {
                // Add new trip
                tripManager.addTrip(newTrip);
                Toast.makeText(this, "Trip saved", Toast.LENGTH_SHORT).show();
            } else {
                // Update existing trip
                tripManager.editTrip(editIndex, newTrip);
                Toast.makeText(this, "Trip updated", Toast.LENGTH_SHORT).show();
            }

            finish(); // Close activity after saving
        });
    }
}
