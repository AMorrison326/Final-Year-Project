package com.example.finalyearproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TripAdapter extends RecyclerView.Adapter<TripAdapter.TripViewHolder> {

    private final Context context;
    private List<Trip> trips; // This will hold the list of trips

    public TripAdapter(Context context) {
        this.context = context;
    }

    // Method to set the list of trips
    public void setTrips(List<Trip> trips) {
        this.trips = trips;
        notifyDataSetChanged(); // Notify the adapter when data changes
    }

    @NonNull
    @Override
    public TripViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout
        View view = LayoutInflater.from(context).inflate(R.layout.item_trip, parent, false);
        return new TripViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TripViewHolder holder, int position) {
        Trip trip = trips.get(position);
        holder.tripNameTextView.setText(trip.getName()); // Set trip name
        holder.tripDestinationTextView.setText(trip.getDestination()); // Set trip destination
        holder.tripStartDateTextView.setText(trip.getStartDate()); // Set trip start date
        holder.tripEndDateTextView.setText(trip.getEndDate()); // Set trip end date
    }

    @Override
    public int getItemCount() {
        return trips == null ? 0 : trips.size(); // Return number of items in the list
    }

    // ViewHolder for each item in the RecyclerView
    public static class TripViewHolder extends RecyclerView.ViewHolder {
        TextView tripNameTextView;
        TextView tripDestinationTextView;
        TextView tripStartDateTextView;
        TextView tripEndDateTextView;

        public TripViewHolder(View itemView) {
            super(itemView);
            tripNameTextView = itemView.findViewById(R.id.trip_name);
            tripDestinationTextView = itemView.findViewById(R.id.trip_destination);
            tripStartDateTextView = itemView.findViewById(R.id.trip_start_date);
            tripEndDateTextView = itemView.findViewById(R.id.trip_end_date);
        }
    }
}
