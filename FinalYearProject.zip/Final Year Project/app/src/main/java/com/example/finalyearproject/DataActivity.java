package com.example.finalyearproject;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashSet;
import java.util.Set;

public class DataActivity extends AppCompatActivity {

    private TextView totalTripsView, mostVisitedView;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        totalTripsView = findViewById(R.id.total_trips);
        mostVisitedView = findViewById(R.id.most_visited);

        sharedPreferences = getSharedPreferences("saved_trips", MODE_PRIVATE);
        Set<String> trips = sharedPreferences.getStringSet("trips", new HashSet<>());

        int totalTrips = trips.size();
        totalTripsView.setText("Total Trips: " + totalTrips);

        // Placeholder for most visited location logic
        mostVisitedView.setText("Most Visited: Not Available Yet");
    }
}
