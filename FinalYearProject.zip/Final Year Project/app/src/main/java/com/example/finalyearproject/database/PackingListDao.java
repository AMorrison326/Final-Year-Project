package com.example.finalyearproject.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface PackingListDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(PackingList item); // ✅ Add this method

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<PackingList> items);

    @Query("SELECT DISTINCT ageGroup FROM packing_list") // Ensure column exists
    LiveData<List<String>> getAgeGroups();

    @Query("SELECT * FROM packing_list WHERE ageGroup = :ageGroup")
    LiveData<List<PackingList>> getPackingListByAgeGroup(String ageGroup);
}
