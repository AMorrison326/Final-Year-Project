package com.example.finalyearproject;

import android.app.Application;
import androidx.lifecycle.LiveData;
import java.util.List;

public class LocationRepository {
    private final LocationDao locationDao;
    private final LiveData<List<Location>> allLocations;

    public LocationRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        locationDao = db.locationDao();
        allLocations = locationDao.getAllLocations();  // ✅ Now correctly returns LiveData
    }

    public LiveData<List<Location>> getAllLocations() {
        return allLocations;
    }
}
