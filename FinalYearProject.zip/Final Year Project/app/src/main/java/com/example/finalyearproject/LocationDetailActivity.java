package com.example.finalyearproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LocationDetailActivity extends AppCompatActivity {
    private TextView locationNameTextView, locationAddressTextView, locationReviewTextView;
    private Button addToJourneyButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_detail);

        // Initialize the views
        locationNameTextView = findViewById(R.id.location_name);
        locationAddressTextView = findViewById(R.id.location_address);
        locationReviewTextView = findViewById(R.id.location_review);
        addToJourneyButton = findViewById(R.id.add_to_journey_button);

        // Get the location details from the intent
        Intent intent = getIntent();
        String name = intent.getStringExtra("location_name");
        String address = intent.getStringExtra("location_address");
        String review = intent.getStringExtra("location_review");

        // Set the retrieved values in the respective TextViews
        locationNameTextView.setText(name);
        locationAddressTextView.setText(address);
        locationReviewTextView.setText(review);

        // Set the click listener for the "Add to Journey" button
        addToJourneyButton.setOnClickListener(v -> {
            // Add the location to the journey (you could save it to a database)
            addLocationToJourney(name, address);
        });
    }

    private void addLocationToJourney(String name, String address) {
        // Logic to add the location to the journey
    }
}
