package com.example.finalyearproject.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "stops")
public class Stops {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String stopName;
    public String tripId; // Foreign key reference to SavedTrip
}
