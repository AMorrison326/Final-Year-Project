package com.example.finalyearproject;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RouteActivity extends AppCompatActivity {

    private RecyclerView routeRecyclerView;
    private RouteAdapter routeAdapter;
    private Button searchRouteButton;
    private List<String> routeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_route);

        // Initialize RecyclerView
        routeRecyclerView = findViewById(R.id.route_list);
        routeRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Example route list
        routeList = new ArrayList<>();
        routeList.add("Route 1: London to Manchester");
        routeList.add("Route 2: London to Birmingham");
        routeList.add("Route 3: London to Liverpool");

        // Set the adapter
        routeAdapter = new RouteAdapter(routeList);  // Pass your list to the adapter
        routeRecyclerView.setAdapter(routeAdapter);

        // Initialize and set up button
        searchRouteButton = findViewById(R.id.search_route_button);
        searchRouteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Filter or modify the route list
                List<String> filteredList = new ArrayList<>();
                for (String route : routeList) {
                    if (route.toLowerCase().contains("london")) {  // For example, filtering routes containing 'London'
                        filteredList.add(route);
                    }
                }

                // Update the adapter with the filtered list
                routeAdapter = new RouteAdapter(filteredList);
                routeRecyclerView.setAdapter(routeAdapter);
            }
        });
    }
}
