pluginManagement {
    repositories {
        google()  // Google's Maven repository for Android tools
        mavenCentral()  // Maven Central for libraries
        gradlePluginPortal()  // Gradle Plugin Portal for additional plugins
    }
}

dependencyResolutionManagement {
    repositories {
        google()  // For Android dependencies
        mavenCentral()  // For other dependencies
    }
}

rootProject.name = "FinalYearProject"
include(":app")
